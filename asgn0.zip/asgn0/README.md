Walter Bergstroem
wbergstr@ucsc.edu

Notes to Grader:
I was a bit confused where you wanted this information which is why I included this README. I'll ask during lab this week so my apologies if I caused any confusion.
